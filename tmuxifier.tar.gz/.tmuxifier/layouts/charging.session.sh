# Set a custom session root path. Default is `$HOME`.
# Must be called before `initialize_session`.
session_root "~/workspace/ev-charging"

# Create session with specified name if it does not already exist. If no
# argument is given, session name will be based on layout file name.
if initialize_session "charging"; then

  # Create a new window inline within session layout definition.
  new_window "terminal"
  new_window "code"
  new_window "lazygit"
  new_window "nvim-config"
  new_window "containers"

  select_window 1
  run_cmd "nvim"

  select_window 2
  run_cmd "lazygit"

  select_window 3
  run_cmd "cd ~/.config/nvim/ && nvim"

  select_window 4
  run_cmd "docker-compose up"

  select_window 1

  # Load a defined window layout.
  #load_window "example"

  # Select the default active window on session creation.
  #select_window 1

fi
# terminal, code, lazy git, nvimconfig
# Finalize session creation and switch/attach to it.
finalize_and_go_to_session
